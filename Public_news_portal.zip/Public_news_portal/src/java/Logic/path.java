/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Logic;

/**
 *
 * @author Sumit
 */
public class path {
    public static String p="C:/Users/waqas/Downloads/Public_news_portal/Public_news_portal/web/";
    public static String name="Public News Portal";
}
